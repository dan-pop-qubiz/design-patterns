﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DesignPatterns.Observer
{
    public class Football: Sport
    {
        public Football(string opponent1, string opponent2): base("Football", opponent1, opponent2)
        {

        }
    }
}
