﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DesignPatterns.ChainOfResponsibility
{
    public class Loan
    {
        public int Amount { get; set; }
        public int PeriodInMonths { get; set; }
        
    }
}
